$("#demo").barcode(
        "1234567890128", // Value barcode (dependent on the type of barcode)
        "ean13" // type (string) 
);